/*
ASSIGNMENT 4 TASK 1: Complex Network Topology
*/

#include <fstream>
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("TASK1");

// Number of Packets Dropped 
int ndrops = 0;

class MyApp : public Application 
{
public:

  MyApp ();
  virtual ~MyApp();

  void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

private:
  virtual void StartApplication (void);
  virtual void StopApplication (void);

  void ScheduleTx (void);
  void SendPacket (void);

  Ptr<Socket>     m_socket;
  Address         m_peer;
  uint32_t        m_packetSize;
  uint32_t        m_nPackets;
  DataRate        m_dataRate;
  EventId         m_sendEvent;
  bool            m_running;
  uint32_t        m_packetsSent;
};

MyApp::MyApp ()
  : m_socket (0), 
    m_peer (), 
    m_packetSize (0), 
    m_nPackets (0), 
    m_dataRate (0), 
    m_sendEvent (), 
    m_running (false), 
    m_packetsSent (0)
{
}

MyApp::~MyApp() {
  m_socket = 0;
}

void MyApp::Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate) {
  m_socket = socket;
  m_peer = address;
  m_packetSize = packetSize;
  m_nPackets = nPackets;
  m_dataRate = dataRate;
}

void MyApp::StartApplication (void) {
  m_running = true;
  m_packetsSent = 0;
  m_socket->Bind ();
  m_socket->Connect (m_peer);
  SendPacket ();
}

void  MyApp::StopApplication (void) {
    m_running = false;

    if (m_sendEvent.IsRunning ()) {
        Simulator::Cancel (m_sendEvent);
    }

    if (m_socket) {
        m_socket->Close ();
    }
}

void MyApp::SendPacket (void) {
    Ptr<Packet> packet = Create<Packet> (m_packetSize);
    m_socket->Send (packet);

    if (++m_packetsSent < m_nPackets) {
        ScheduleTx ();
    }
}

void MyApp::ScheduleTx (void) {
    if (m_running) {
        Time tNext (Seconds (m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate ())));
        m_sendEvent = Simulator::Schedule (tNext, &MyApp::SendPacket, this);
    }
}

static void CwndChange (Ptr<OutputStreamWrapper> stream, uint32_t oldCwnd, uint32_t newCwnd) {
    *stream->GetStream () << Simulator::Now ().GetSeconds () << "," << newCwnd << std::endl;
}

// static void RxDrop (Ptr<const Packet> p) {
//     // NS_LOG_UNCOND ("RxDrop at " << Simulator::Now ().GetSeconds ());
//     ndrops += 1;
// }

int main (int argc, char *argv[]) {
    CommandLine cmd;
    cmd.Parse (argc, argv);

    NodeContainer nodes;

    // Create five nodes 
    nodes.Create(3);

    // Create Node Connections
    NodeContainer n_13 = NodeContainer(nodes.Get(0),nodes.Get(2)); 
    NodeContainer n_23 = NodeContainer(nodes.Get(1),nodes.Get(2));

    PointToPointHelper pointToPoint;

    // Datarate of the links & propogation delay for 1-3 link
    pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("10Mbps"));
    pointToPoint.SetChannelAttribute ("Delay", StringValue ("3ms"));
    NetDeviceContainer devices_13 = pointToPoint.Install(n_13);

    // Datarate of the links & propogation delay for 2-3 link
    pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("9Mbps"));
    pointToPoint.SetChannelAttribute ("Delay", StringValue ("3ms"));
    NetDeviceContainer devices_23 = pointToPoint.Install(n_23);

    // RateErrorModel used at N2 with error rate 0.00001
    Ptr<RateErrorModel> em = CreateObject<RateErrorModel> ();
    em->SetAttribute ("ErrorRate", DoubleValue (0.00001));
    devices_13.Get(1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));
    devices_23.Get(1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));

    InternetStackHelper stack;
    stack.Install(nodes);

    // Assign IPv4 addresses to each of the nodes
    Ipv4AddressHelper address;

    address.SetBase("10.1.1.0", "255.255.255.252");
    Ipv4InterfaceContainer interfaces_13 = address.Assign(devices_13);

    address.SetBase("10.1.2.0", "255.255.255.252");
    Ipv4InterfaceContainer interfaces_23 = address.Assign(devices_23);

    // Create Sockets 
    // TCP Socket 1: For connecting node 1 - 3
    // TCP Socket 2: For connecting node 2 - 3

    // SINK NODES
    // 3 TCP sinks at node 3

    // Connection 1
    uint16_t sinkPort1 = 8080;
    Address sinkAddress1(InetSocketAddress (interfaces_13.GetAddress(1), sinkPort1));
    PacketSinkHelper packetSinkHelper1("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), sinkPort1));
    ApplicationContainer sinkApps1 = packetSinkHelper1.Install(nodes.Get(2));
    sinkApps1.Start (Seconds (1.));
    sinkApps1.Stop (Seconds (20.));

    // Connection 2
    uint16_t sinkPort2 = 8085;
    Address sinkAddress2(InetSocketAddress (interfaces_13.GetAddress(1), sinkPort2));
    PacketSinkHelper packetSinkHelper2("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), sinkPort2));
    ApplicationContainer sinkApps2 = packetSinkHelper2.Install(nodes.Get(2));
    sinkApps2.Start (Seconds (5.));
    sinkApps2.Stop (Seconds (25.));

    // Connection 3
    uint16_t sinkPort3 = 8090;
    Address sinkAddress3(InetSocketAddress (interfaces_23.GetAddress(1), sinkPort3));
    PacketSinkHelper packetSinkHelper3("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), sinkPort3));
    ApplicationContainer sinkApps3 = packetSinkHelper3.Install(nodes.Get(2));
    sinkApps3.Start (Seconds (15.));
    sinkApps3.Stop (Seconds (30.));

    AsciiTraceHelper asciiTraceHelper;
    Ptr<OutputStreamWrapper> stream0 = asciiTraceHelper.CreateFileStream ("./cwnd_c1.csv");
    Ptr<OutputStreamWrapper> stream1 = asciiTraceHelper.CreateFileStream ("./cwnd_c2.csv");
    Ptr<OutputStreamWrapper> stream2 = asciiTraceHelper.CreateFileStream ("./cwnd_c3.csv");

    std::string id ="ns3::TcpNewRenoPlus";
    TypeId tid = TypeId::LookupByName(id);
    Config::Set ("/NodeList/*/$ns3::TcpL4Protocol/SocketType", TypeIdValue (tid));

    // TCP Socket 1 at Node 1
    Ptr<Socket> ns3TcpSocket0 = Socket::CreateSocket (nodes.Get(0), TcpSocketFactory::GetTypeId ());
    ns3TcpSocket0->TraceConnectWithoutContext ("CongestionWindow", MakeBoundCallback(&CwndChange, stream0));

    Ptr<Socket> ns3TcpSocket1 = Socket::CreateSocket (nodes.Get(0), TcpSocketFactory::GetTypeId ());
    ns3TcpSocket1->TraceConnectWithoutContext ("CongestionWindow", MakeBoundCallback(&CwndChange, stream1));

    Ptr<Socket> ns3TcpSocket2 = Socket::CreateSocket (nodes.Get(1), TcpSocketFactory::GetTypeId ());
    ns3TcpSocket2->TraceConnectWithoutContext ("CongestionWindow", MakeBoundCallback(&CwndChange, stream2));

    // Setup TCP Application
    Ptr<MyApp> app1 = CreateObject<MyApp> ();
    // socket, address, packetSize, nPackets, dataRate
    app1->Setup (ns3TcpSocket0, sinkAddress1, 3000, 100000000, DataRate ("1.5Mbps"));
    nodes.Get(0)->AddApplication(app1);
    app1->SetStartTime (Seconds (1.));
    app1->SetStopTime (Seconds (20.));

    Ptr<MyApp> app2 = CreateObject<MyApp> ();
    // socket, address, packetSize, nPackets, dataRate
    app2->Setup (ns3TcpSocket1, sinkAddress2, 3000, 100000000, DataRate ("1.5Mbps"));
    nodes.Get(0)->AddApplication(app2);
    app2->SetStartTime (Seconds (5.));
    app2->SetStopTime (Seconds (25.));

    Ptr<MyApp> app3 = CreateObject<MyApp> ();
    // socket, address, packetSize, nPackets, dataRate
    app3->Setup (ns3TcpSocket2, sinkAddress3, 3000, 100000000, DataRate ("1.5Mbps"));
    nodes.Get(0)->AddApplication(app3);
    app3->SetStartTime (Seconds (15.));
    app3->SetStopTime (Seconds (30.));

    Ipv4GlobalRoutingHelper::PopulateRoutingTables ();
    pointToPoint.EnablePcapAll ("a4_partA");

    Simulator::Stop (Seconds(30));
    Simulator::Run ();
    Simulator::Destroy ();

    std::cout << "No of packet drops: " << ndrops << std::endl; 

    return 0;
}

