/*
TASK 3: Complex Network Topology
*/

#include <fstream>
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("TASK1");

// Number of Packets Dropped 
int ndrops = 0;

class MyApp : public Application 
{
public:

  MyApp ();
  virtual ~MyApp();

  void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

private:
  virtual void StartApplication (void);
  virtual void StopApplication (void);

  void ScheduleTx (void);
  void SendPacket (void);

  Ptr<Socket>     m_socket;
  Address         m_peer;
  uint32_t        m_packetSize;
  uint32_t        m_nPackets;
  DataRate        m_dataRate;
  EventId         m_sendEvent;
  bool            m_running;
  uint32_t        m_packetsSent;
};

MyApp::MyApp ()
  : m_socket (0), 
    m_peer (), 
    m_packetSize (0), 
    m_nPackets (0), 
    m_dataRate (0), 
    m_sendEvent (), 
    m_running (false), 
    m_packetsSent (0)
{
}

MyApp::~MyApp() {
  m_socket = 0;
}

void MyApp::Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate) {
  m_socket = socket;
  m_peer = address;
  m_packetSize = packetSize;
  m_nPackets = nPackets;
  m_dataRate = dataRate;
}

void MyApp::StartApplication (void) {
  m_running = true;
  m_packetsSent = 0;
  m_socket->Bind ();
  m_socket->Connect (m_peer);
  SendPacket ();
}

void  MyApp::StopApplication (void) {
    m_running = false;

    if (m_sendEvent.IsRunning ()) {
        Simulator::Cancel (m_sendEvent);
    }

    if (m_socket) {
        m_socket->Close ();
    }
}

void MyApp::SendPacket (void) {
    Ptr<Packet> packet = Create<Packet> (m_packetSize);
    m_socket->Send (packet);

    if (++m_packetsSent < m_nPackets) {
        ScheduleTx ();
    }
}

void MyApp::ScheduleTx (void) {
    if (m_running) {
        Time tNext (Seconds (m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate ())));
        m_sendEvent = Simulator::Schedule (tNext, &MyApp::SendPacket, this);
    }
}

static void CwndChange (Ptr<OutputStreamWrapper> stream, uint32_t oldCwnd, uint32_t newCwnd) {
    *stream->GetStream () << Simulator::Now ().GetSeconds () << "," << newCwnd << std::endl;
}

static void RxDrop (Ptr<const Packet> p) {
    // NS_LOG_UNCOND ("RxDrop at " << Simulator::Now ().GetSeconds ());
    ndrops += 1;
}

int main (int argc, char *argv[]) {
    CommandLine cmd;
    cmd.Parse (argc, argv);

    NodeContainer nodes;

    // Create five nodes 
    nodes.Create(5);

    // Create Node Connections
    NodeContainer n_12 = NodeContainer(nodes.Get(0),nodes.Get(1)); 
    NodeContainer n_23 = NodeContainer(nodes.Get(1),nodes.Get(2));
    NodeContainer n_34 = NodeContainer(nodes.Get(2),nodes.Get(3));
    NodeContainer n_35 = NodeContainer(nodes.Get(2),nodes.Get(4));

    PointToPointHelper pointToPoint;

    // Datarate of the links
    pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("500Kbps"));
    // Propogation Delay
    pointToPoint.SetChannelAttribute ("Delay", StringValue ("2ms"));

    // Install the P2P on all nodes
    NetDeviceContainer devices_12 = pointToPoint.Install(n_12);
    NetDeviceContainer devices_23 = pointToPoint.Install(n_23);
    NetDeviceContainer devices_34 = pointToPoint.Install(n_34);
    NetDeviceContainer devices_35 = pointToPoint.Install(n_35);

    // RateErrorModel used at N2 with error rate 0.00001
    Ptr<RateErrorModel> em = CreateObject<RateErrorModel> ();
    em->SetAttribute ("ErrorRate", DoubleValue (0.00001));
    devices_12.Get(1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));
    devices_23.Get(1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));
    devices_34.Get(1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));
    devices_35.Get(1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));

    InternetStackHelper stack;
    stack.Install (nodes);

    // Assign IPv4 addresses to each of the nodes
    Ipv4AddressHelper address;
    address.SetBase("10.1.1.0", "255.255.255.252");
    Ipv4InterfaceContainer interfaces_12 = address.Assign(devices_12);

    address.SetBase("10.1.2.0", "255.255.255.252");
    Ipv4InterfaceContainer interfaces_23 = address.Assign(devices_23);

    address.SetBase("10.1.3.0", "255.255.255.252");
    Ipv4InterfaceContainer interfaces_34 = address.Assign(devices_34);

    address.SetBase("10.1.4.0", "255.255.255.252");
    Ipv4InterfaceContainer interfaces_35 = address.Assign(devices_35);

    // Create Sockets 
    // TCP Socket: For connecting node 1 - 4
    // UDP Socket: For connecting node 5 - 2

    // SINK NODES

    // TCP Sink at node 4
    uint16_t sinkPort4 = 8080;
    Address sinkAddress4(InetSocketAddress (interfaces_34.GetAddress(1), sinkPort4));
    PacketSinkHelper packetSinkHelper1("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), sinkPort4));
    ApplicationContainer sinkApps4 = packetSinkHelper1.Install(nodes.Get(3));
    sinkApps4.Start (Seconds (1.));
    sinkApps4.Stop (Seconds (100.));

    // UDP Sink at node 2 (Till 30 s)
    uint16_t sinkPort2 = 8082;
    Address sinkAddress2(InetSocketAddress (interfaces_23.GetAddress(0), sinkPort2));
    PacketSinkHelper packetSinkHelper2("ns3::UdpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), sinkPort2));
    ApplicationContainer sinkApps2 = packetSinkHelper2.Install(nodes.Get(1));
    sinkApps2.Start (Seconds (20.));
    sinkApps2.Stop (Seconds (100.));

    // TCP Socket at node 1
    AsciiTraceHelper asciiTraceHelper;
    Ptr<OutputStreamWrapper> stream = asciiTraceHelper.CreateFileStream ("./plots/task3/sim.csv");

    std::string id ="ns3::TcpVegas";
    TypeId tid = TypeId::LookupByName(id);
    Config::Set ("/NodeList/*/$ns3::TcpL4Protocol/SocketType", TypeIdValue (tid));

    Ptr<Socket> ns3TcpSocket1 = Socket::CreateSocket (nodes.Get(0), TcpSocketFactory::GetTypeId ());
    ns3TcpSocket1->TraceConnectWithoutContext ("CongestionWindow", MakeBoundCallback(&CwndChange, stream));

    Ptr<Socket> ns3UdpSocket5 = Socket::CreateSocket(nodes.Get(4), UdpSocketFactory::GetTypeId());

    // Setup TCP Application
    Ptr<MyApp> tcp_app = CreateObject<MyApp> ();
    // socket, address, packetSize, nPackets, dataRate
    tcp_app->Setup (ns3TcpSocket1, sinkAddress4, 1040, 100000, DataRate ("250Kbps"));
    nodes.Get(0)->AddApplication(tcp_app);
    tcp_app->SetStartTime (Seconds (1.));
    tcp_app->SetStopTime (Seconds (100.));

    // Setup UDP Application
    Ptr<MyApp> udp_app = CreateObject<MyApp> ();
    // socket, address, packetSize, nPackets, dataRate
    udp_app->Setup (ns3UdpSocket5, sinkAddress2, 1040, 100000, DataRate ("250Kbps"));
    nodes.Get(4)->AddApplication(udp_app);
    udp_app->SetStartTime (Seconds (20.));
    udp_app->SetStopTime (Seconds (100.));

    Ptr<MyApp> udp_app2 = CreateObject<MyApp> ();
    // socket, address, packetSize, nPackets, dataRate
    udp_app2->Setup (ns3UdpSocket5, sinkAddress2, 1040, 100000, DataRate ("250Kbps"));
    nodes.Get(4)->AddApplication(udp_app2);
    udp_app2->SetStartTime (Seconds (30.));
    udp_app2->SetStopTime (Seconds (100.));

    devices_34.Get(1)->TraceConnectWithoutContext ("PhyRxDrop", MakeCallback(&RxDrop));

    Ipv4GlobalRoutingHelper::PopulateRoutingTables ();
    pointToPoint.EnablePcapAll ("task3");

    Simulator::Stop (Seconds(100));
    Simulator::Run ();
    Simulator::Destroy ();

    std::cout << "No of packet drops: " << ndrops << std::endl; 

    return 0;
}

