import matplotlib.pyplot as plt
import csv

filename = "sim.csv"

data = csv.reader(open(filename, 'r'), delimiter=",")
x = []
y = []
for row in data:
  x.append(float(row[0]))
  y.append(float(row[1]))

plt.figure(figsize=(10, 10))
plt.plot(x,y, color="orange")

plt.xlabel('Time')
plt.ylabel('cwnd')

# plt.savefig(filename+'.png')  
plt.show()