import matplotlib.pyplot as plt
import csv

filename = "a"
for i in range(1,6):
  data = csv.reader(open(filename+str(i)+'.csv', 'r'), delimiter=",")
  x = []
  y = []
  for row in data:
    x.append(float(row[0]))
    y.append(float(row[1]))

  plt.figure(figsize=(10, 10))
  plt.plot(x,y, color="indigo")

  plt.xlabel('Time')
  plt.ylabel('cwnd')

  plt.savefig(filename+str(i)+'.png')  

filename = "b"
for i in range(1,6):
  data = csv.reader(open(filename+str(i)+'.csv', 'r'), delimiter=",")
  x = []
  y = []
  for row in data:
    x.append(float(row[0]))
    y.append(float(row[1]))

  plt.figure(figsize=(10, 10))
  plt.plot(x,y, color="indigo")

  plt.xlabel('Time')
  plt.ylabel('cwnd')

  plt.savefig(filename+str(i)+'.png')  