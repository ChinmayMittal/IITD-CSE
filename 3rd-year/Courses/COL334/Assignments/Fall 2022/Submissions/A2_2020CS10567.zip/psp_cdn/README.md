# PSP Content Distribution Network 
This project is an implementation of a Peer-Server-Peer (PSP) Content Distribution Network, implemented using Python. 

## Running the Shell Script 
To run the shell script, simply type the following command inside the project directory: `./2020CS10567.sh` 
The simulation will then run for `n=5` clients and the input file `A2_small_file.txt`. The client side files will be generated in the directory `.\clientfiles`, and their MD5 hash will be printed out on the terminal. 

